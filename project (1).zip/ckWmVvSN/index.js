import java.io.*


class coorp1 {
    wholeName;
    birthDate;
    
        wholeInformation(wholeName, birthDate){
            this.wholeName = n;
            this.birthDate = b;
        }
     
}

class evilCorp {
    public static void main (String[], arguments){
        coorp1[] = getInfo();
        
        for (int i = 0; i < s.length; i++)
        System.out.prints(s[i].wholeName + ', \n' + s[i].birthDate );
    }
}

public static wholeName[] getInfo(){
    Whole[] a = new Info[4];
    
    a[1] = new Info ('John Pardi', 'Jan 14')
    a[2] = new Info ('Iris Bell', 'Feb 12')
    a[3] = new Info ('George Straight', 'Old af')
    
    return a;
}